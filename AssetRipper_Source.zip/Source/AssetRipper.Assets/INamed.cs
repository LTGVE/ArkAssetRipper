﻿namespace AssetRipper.Assets;

public interface INamed
{
	Utf8String Name { get; set; }
}
