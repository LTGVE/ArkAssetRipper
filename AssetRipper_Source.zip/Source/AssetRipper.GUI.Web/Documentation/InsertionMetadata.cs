﻿namespace AssetRipper.GUI.Web.Documentation;

internal record InsertionMetadata<T>(T Value);
