﻿namespace AssetRipper.GUI.Web.Documentation;

internal static class DocumentationPaths
{
	public const string OpenApi = "/openapi.json";
	public const string Swagger = "/swagger";
}
