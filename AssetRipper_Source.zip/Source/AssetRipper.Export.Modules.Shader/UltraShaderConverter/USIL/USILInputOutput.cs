﻿namespace AssetRipper.Export.Modules.Shaders.UltraShaderConverter.USIL;

public class USILInputOutput
{
	public required string type;
	public required string name;
	public int register;
	public int mask;
	public bool isOutput;
}
