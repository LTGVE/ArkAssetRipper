﻿namespace AssetRipper.Export.Modules.Shaders.UltraShaderConverter.USIL;

public enum USILLocalType
{
	Scalar,
	Vector2,
	Vector3,
	Vector4,
	Matrix4x4
}
