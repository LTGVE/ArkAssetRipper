﻿namespace AssetRipper.Export.Modules.Shaders.UltraShaderConverter.USIL;

// todo: USILInstruction use this too
public enum USILNumberType
{
	Float,
	Int,
	UnsignedInt
}
