﻿namespace AssetRipper.Export.Modules.Shaders.UltraShaderConverter.UShader.Function;

public enum UShaderFunctionType
{
	Unknown,
	Vertex,
	Fragment
}