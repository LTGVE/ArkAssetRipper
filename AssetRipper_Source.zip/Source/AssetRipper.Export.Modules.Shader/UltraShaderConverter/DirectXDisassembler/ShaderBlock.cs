﻿namespace AssetRipper.Export.Modules.Shaders.UltraShaderConverter.DirectXDisassembler;

public abstract class ShaderBlock
{
	public abstract string FourCC { get; }
}
