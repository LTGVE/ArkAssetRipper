﻿# Shader Text Restorer

This project handles all the efforts to restore shaders to something resembling the original shader.

Basic blob export is currently possible for most shaders.