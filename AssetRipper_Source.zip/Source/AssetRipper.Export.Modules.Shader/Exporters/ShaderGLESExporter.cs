﻿namespace AssetRipper.Export.Modules.Shaders.Exporters;

public class ShaderGLESExporter : ShaderTextExporter
{
	public override string Name => "ShaderGLESExporter";
}
