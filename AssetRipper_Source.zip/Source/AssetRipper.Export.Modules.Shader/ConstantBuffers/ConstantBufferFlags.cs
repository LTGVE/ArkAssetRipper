namespace AssetRipper.Export.Modules.Shaders.ConstantBuffers;

public enum ConstantBufferFlags
{
	None = 0,
	UserPacked = 1,
}