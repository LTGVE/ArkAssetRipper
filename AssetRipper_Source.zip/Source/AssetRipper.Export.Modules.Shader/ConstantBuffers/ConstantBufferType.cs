﻿namespace AssetRipper.Export.Modules.Shaders.ConstantBuffers;

internal enum ConstantBufferType
{
	ConstantBuffer,
	TextureBuffer,
	InterfacePointers,
	ResourceBindInformation,
}
