﻿namespace AssetRipper.Export.Modules.Shaders.Resources;

internal record Sampler(string Name, uint BindPoint, bool IsComparisonSampler)
{
}
