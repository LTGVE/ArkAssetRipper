﻿namespace AssetRipper.Export.Modules.Shaders.Resources;

internal enum SamplerFilterMode
{
	Point,
	Linear,
	Trilinear,
}
