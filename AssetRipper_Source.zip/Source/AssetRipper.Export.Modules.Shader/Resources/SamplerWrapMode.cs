﻿namespace AssetRipper.Export.Modules.Shaders.Resources;

internal enum SamplerWrapMode
{
	Repeat,
	Clamp,
	Mirror,
	MirrorOnce,
}
