using AssetRipper.GUI.Web;

WebApplicationLauncher.Launch(args);
