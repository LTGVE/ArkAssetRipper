﻿namespace AssetRipper.Export.UnityProjects.PathIdMapping;

internal sealed class SerializedGameInfo
{
	public List<SerializedFileInfo> Files { get; set; } = new();
}
