﻿namespace AssetRipper.Export.UnityProjects.Shaders;

internal sealed class TemplateJson
{
	public List<TemplateShader> Templates { get; set; } = new();
}
